Copyright (2012) by the Authors


These files were generated with the following models (dataset in parentheses):

1. RBM (JSB chorales)
2. RNN (M.C. Mozer, Connection Science 6(2):247-280, 1994)
3. RTRBM (Mozer)
4. RNN-RBM (Mozer)
5. RNN-RBM (Mozer)
6. RNN-RBM (Nottingham)
7. RNN-NADE (Piano-midi.de)
8. RNN-NADE (Nottingham)
9. RNN-NADE (JSB chorales)


